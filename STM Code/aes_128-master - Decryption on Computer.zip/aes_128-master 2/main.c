/*
 *
 * Chinese Academy of Sciences
 * State Key Laboratory of Information Security
 * Institute of Information Engineering
 *
 * Copyright (C) 2016 Chinese Academy of Sciences
 *
 * LuoPeng, luopeng@iie.ac.cn
 * Updated in May 2016
 *
 */

#include <stdio.h>

#include "aes.h"

int main()
{
	
	
	printf("\n\n\nrunning");
	FILE *fp1;
	fp1 = fopen("EncryptionTesting.csv", "r");

	if (fp1 == NULL)
	{
		printf("Error : Files not open");
		// exit(0);
	}
	//int nextLine[540511];
	char ch1 = getc(fp1);
	int k = 0;
	char plaintextdefault[800000];
	// while (ch1 != EOF)
	for (size_t p = 0; p < 800000; p++)
	//for (size_t p = 0; p < 10; p++)
	{

		plaintextdefault[k] = ch1;
		ch1 = getc(fp1);
	
		k++;
		if(ch1==EOF)
		{
			break;
		}
	}

	uint8_t plaintext[k];
	int noofloops = (k / AES_BLOCK_SIZE) + 1;
	char ciphertext[noofloops * AES_BLOCK_SIZE];
	char decryptedtext[noofloops * AES_BLOCK_SIZE];
	uint8_t roundkeys[AES_ROUND_KEY_SIZE * noofloops];

	for (size_t i = 0; i < k; i++)
	{
		plaintext[i] = (uint8_t)plaintextdefault[i];
	}

	printf("\n--------------------------------------------------------\n");
	printf("Plain text:\n ");
	for (size_t i = 0; i < k - 1; i++)
	{
		printf("%c", ((char)plaintext[i]));
	}
	printf("\n\n");

	for (size_t i = 0; i < noofloops; i++)
	{

		uint8_t plaintexttemp[AES_BLOCK_SIZE];

		for (size_t j = 0; j < AES_BLOCK_SIZE; j++)
		{
			if (((AES_BLOCK_SIZE * i) + j) > k)
			{
				plaintexttemp[j] = 0;
			}
			else
			{
				plaintexttemp[j] = plaintext[(AES_BLOCK_SIZE * i) + j];
			}
		}



		/* 128 bit key */
		uint8_t key[] = {
			// 0x0f, 0x15, 0x71, 0xc9, 0x47, 0xd9, 0xe8, 0x59,
			// 0x0c, 0xb7, 0xad, 0xd6, 0xaf, 0x7f, 0x67, 0x98,
			0x00,
			0x01,
			0x02,
			0x03,
			0x04,
			0x05,
			0x06,
			0x07,
			0x08,
			0x09,
			0x0a,
			0x0b,
			0x0c,
			0x0d,
			0x0e,
			0x0f,

		};

	

		uint8_t ciphertexttemp[AES_BLOCK_SIZE];
		uint8_t roundkeystemp[AES_ROUND_KEY_SIZE];

		

		// printf("\n--------------------------------------------------------\n");
		// printf("Read Successful/nPlain text:\n ");
		// for (i = 0; i < AES_BLOCK_SIZE; i++)
		// {
		// 	printf("%2x ", plaintexttemp[i]);
		// }
		// printf("\n\n");

		// key schedule
		aes_key_schedule_128(key, roundkeystemp);


		// encryption
		aes_encrypt_128(roundkeystemp, plaintexttemp, ciphertexttemp);

		for (size_t j = 0; j < AES_BLOCK_SIZE; j++)
		{
			ciphertext[(AES_BLOCK_SIZE * i) + j] = ciphertexttemp[j];
		}

		for (size_t j = 0; j < AES_ROUND_KEY_SIZE; j++)
		{
			roundkeys[(AES_ROUND_KEY_SIZE * i) + j] = roundkeystemp[j];
		}

	}
	printf("\n--------------------------------------------------------\n");
	printf("Encrypted text:\n ");
	for (size_t i = 0; i < k - 1; i++)
	{

		printf("%c", (char)ciphertext[i]);
	}
	printf("\n\n");

	FILE *fp;
	fp = fopen("EncryptedText.csv", "w");

	//printf("\n\nWORKING\n\n");

	for (size_t i = 0; i < k-1; i++)
	{
		
			fprintf(fp, "%c", (char)ciphertext[i]);
	}

	//printf("\n\nWORKING\n\n");
	printf("%i", k);
	fclose(fp);

	for (size_t i = 0; i < noofloops; i++)
	{
		// decryption

		uint8_t ciphertexttemp[AES_BLOCK_SIZE];
		uint8_t roundkeystemp[AES_ROUND_KEY_SIZE];

		for (size_t j = 0; j < AES_BLOCK_SIZE; j++)
		{
			ciphertexttemp[j] = ciphertext[(AES_BLOCK_SIZE * i) + j];
		}
		for (size_t j = 0; j < AES_ROUND_KEY_SIZE; j++)
		{
			roundkeystemp[j] = roundkeys[(AES_ROUND_KEY_SIZE * i) + j];
		}

		aes_decrypt_128(roundkeystemp, ciphertexttemp, ciphertexttemp);

		for (size_t j = 0; j < AES_BLOCK_SIZE; j++)
		{

			decryptedtext[(AES_BLOCK_SIZE * i) + j] = ciphertexttemp[j];
		}
	}

	printf("\n--------------------------------------------------------\n");
	printf("Decrypted text:\n ");
	for (size_t i = 0; i < k - 1; i++)
	{
		// char output[2];
		// sprintf(output, "%c", (int) decryptedtext[i]);
		// printf("%s ", output);
		printf("%c", (char)decryptedtext[i]);
	}
	printf("\n\n");

	// printf("Plain text:\n");
	//  for (i = 0; i < AES_BLOCK_SIZE; i++)
	//  {
	//  	printf("%2x ", ciphertext[i]);
	//  }
	//  for (i = 0; i < AES_BLOCK_SIZE; i++)
	//  {
	//  	if (ciphertext[i] != plaintext[i])
	//  	{
	//  		break;
	//  	}
	//  }
	//  if (AES_BLOCK_SIZE != i)
	//  {
	//  	printf("\nDECRYPT WRONG\n\n");
	//  }
	//  else
	//  {
	//  	printf("\nDECRYPT CORRECT\n\n");
	//  }

	// 	for (int i = 0; i < 10; i++)
	// 	{
	// 		fprintf(fp2, "%d", ciphertext[i]);
	// 		fprintf(fp2, "hello\n");
	// 		if (ferror(fp2))
	// 		{
	// 			printf("error");
	// 		}
	// 	}

	
FILE *fp2;
	fp2 = fopen("DecryptedText.csv", "w");

	//printf("\n\nWORKING\n\n");

	for (size_t i = 0; i < k-1; i++)
	{
		
			fprintf(fp2, "%c", (char)decryptedtext[i]);
	}

	//printf("\n\nWORKING\n\n");
	printf("%i", k);
	fclose(fp2);
	
	fclose(fp1);

	return 0;
}
